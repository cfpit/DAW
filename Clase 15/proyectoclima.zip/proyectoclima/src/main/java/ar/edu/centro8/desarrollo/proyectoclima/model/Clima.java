package ar.edu.centro8.desarrollo.proyectoclima.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Clima {

    private String ciudad;
    private Double temperatura;
    private Double sensacionTermica;
    private Integer humedad;
    private Double viento;
    private Double precipitacion;
    private String descripcion;
    private String iconoBootstrap;
    private String iconoEmoji;
    private String horaActualizacion;

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public Double getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(Double temperatura) {
        this.temperatura = temperatura;
    }

    public Double getSensacionTermica() {
        return sensacionTermica;
    }

    public void setSensacionTermica(Double sensacionTermica) {
        this.sensacionTermica = sensacionTermica;
    }

    public Integer getHumedad() {
        return humedad;
    }

    public void setHumedad(Integer humedad) {
        this.humedad = humedad;
    }

    public Double getViento() {
        return viento;
    }

    public void setViento(Double viento) {
        this.viento = viento;
    }

    public Double getPrecipitacion() {
        return precipitacion;
    }

    public void setPrecipitacion(Double precipitacion) {
        this.precipitacion = precipitacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getIconoBootstrap() {
        return iconoBootstrap;
    }

    public void setIconoBootstrap(String iconoBootstrap) {
        this.iconoBootstrap = iconoBootstrap;
    }

    public String getIconoEmoji() {
        return iconoEmoji;
    }

    public void setIconoEmoji(String iconoEmoji) {
        this.iconoEmoji = iconoEmoji;
    }

    public String getHoraActualizacion() {
        return horaActualizacion;
    }

    public void setHoraActualizacion(String horaActualizacion) {
        this.horaActualizacion = horaActualizacion;
    }
}
