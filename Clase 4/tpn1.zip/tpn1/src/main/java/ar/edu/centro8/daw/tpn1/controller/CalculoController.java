package ar.edu.centro8.daw.tpn1.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CalculoController {
    
    // Constante para la conversión de galones a litros
    private static final double GALONES_A_LITROS = 3.78541;
    
    //endpoint: http://localhost:8080/conversion?galones=5.5
    @GetMapping("/conversion")
    public String convertirGalonesALitros(@RequestParam double galones) {        
        double litros = galones * GALONES_A_LITROS;
        return String.format("%.2f galones equivalen a %.2f litros", galones, litros);
    }
    
    //endpoint: http://localhost:8080/promedio?nota1=8.5&nota2=7.0&nota3=9.2
    @GetMapping("/promedio")
    public String calcularPromedio(@RequestParam double nota1, @RequestParam double nota2, @RequestParam double nota3) {
        double promedio = (nota1 + nota2 + nota3) / 3;
        return String.format("El promedio de las notas %.2f, %.2f y %.2f es: %.2f", nota1, nota2, nota3, promedio);
    }
}
