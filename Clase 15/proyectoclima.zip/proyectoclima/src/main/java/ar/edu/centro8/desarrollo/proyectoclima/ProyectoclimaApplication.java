package ar.edu.centro8.desarrollo.proyectoclima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class ProyectoclimaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoclimaApplication.class, args);
    }

    // Configuración del bean RestTemplate para realizar peticiones HTTP a APIs externas
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

}

