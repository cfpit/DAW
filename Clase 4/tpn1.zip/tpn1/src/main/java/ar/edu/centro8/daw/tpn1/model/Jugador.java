package ar.edu.centro8.daw.tpn1.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Jugador {
    
    private Long id;
    private String dni;
    private String nombre;
    private String apellido;
    private int edad;
    private double peso;  // en kg
    private double estatura;  // en metros (ej: 1.85)
    
}
