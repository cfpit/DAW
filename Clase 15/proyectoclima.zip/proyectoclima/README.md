# Proyecto Clima CABA ☀️🌧️

Este proyecto es una aplicación desarrollada en **Spring Boot 3** para la materia *Desarrollo de Aplicaciones Web (DAW)*. 

Su función principal es consumir una **API REST externa pública** para obtener las condiciones meteorológicas en tiempo real de la **Ciudad Autónoma de Buenos Aires (CABA)** y mostrarlas tanto en una **página web responsiva (HTML + Thymeleaf + Bootstrap 5)** como a través de un **endpoint REST propio en formato JSON**.

---

## 📌 Diferencias clave con `proyectosbon2`

1. **Sin clase `Persona` ni Base de Datos**: A diferencia de `proyectosbon2` que utilizaba Spring Data JPA y MySQL (`jdbc:mysql://localhost:3306/chino2`), este proyecto **no requiere base de datos ni entidades JPA**. Inicia en menos de 2 segundos de manera totalmente autónoma.
2. **Consumo de API Externa**: Se tomó el patrón de `DolarService` / `DolarController` de `proyectosbon2` y se adaptó para el clima con la API meteorológica global **Open-Meteo**.
3. **Colección Bruno incluida**: Carpeta `bruno/` lista para importar y probar los endpoints sin necesidad de configurar nada manualmente.

---

## 📂 Estructura del Proyecto

```text
proyectoclima/
├── bruno/                                         # Colección de pruebas para Bruno API Client
│   ├── bruno.json                                 # Metadatos de la colección
│   ├── collection.bru                             # Variables de entorno (baseUrl = http://localhost:8080)
│   ├── Obtener Clima CABA (JSON API).bru          # GET /api/clima
│   ├── Obtener Clima CABA (Vista HTML).bru         # GET /clima
│   └── API Externa Open-Meteo Directa.bru         # GET directo a la API de Open-Meteo
├── pom.xml                                        # Dependencias Maven (Web, Thymeleaf, Test, Devtools)
├── src/
│   ├── main/
│   │   ├── java/ar/edu/centro8/desarrollo/proyectoclima/
│   │   │   ├── ProyectoclimaApplication.java      # Clase principal y definición del Bean RestTemplate
│   │   │   ├── controller/
│   │   │   │   └── ClimaController.java            # Controlador web (Thymeleaf) y REST (JSON)
│   │   │   ├── model/
│   │   │   │   ├── Clima.java                      # Modelo de datos de negocio en español
│   │   │   │   └── OpenMeteoResponse.java          # Mapeo del JSON crudo devuelto por la API
│   │   │   └── service/
│   │   │       └── ClimaService.java               # Capa de servicio (lógica de negocio y llamadas HTTP)
│   │   └── resources/
│   │       ├── application.properties              # Configuración y URL de la API externa
│   │       └── templates/
│   │           └── clima.html                      # Vista HTML responsiva con Bootstrap 5.3
│   └── test/
│       └── java/ar/edu/centro8/desarrollo/proyectoclima/
│           ├── ProyectoclimaApplicationTests.java  # Test de carga de contexto
│           └── ClimaServiceTest.java               # Test de integración real con la API externa
```

---

## 🔍 Explicación Detallada de `ClimaService`

La clase `ClimaService` representa la **Capa de Servicio (`@Service`)** dentro del patrón arquitectónico MVC (Modelo - Vista - Controlador) de Spring. Su responsabilidad es aislar la lógica de conexión externa y procesamiento de datos para que el controlador (`ClimaController`) solo se preocupe por atender las solicitudes de los usuarios.

A continuación se desglosan los aspectos fundamentales de su funcionamiento:

### 1. Inyección de la URL Externa (`@Value`)
```java
@Value("${clima.api.url}")
private String climaApiUrl;
```
- En lugar de "quemar" (hardcodear) la URL de la API externa dentro del código Java, se utiliza la anotación `@Value`.
- Spring lee automáticamente la clave `clima.api.url` desde el archivo `src/main/resources/application.properties`:
  ```properties
  clima.api.url=https://api.open-meteo.com/v1/forecast?latitude=-34.6037&longitude=-58.3816&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=auto
  ```
- **Ventaja**: Si el día de mañana se desean cambiar las coordenadas a otra provincia o país, solo se edita el archivo `.properties` sin recompilar el código Java.

### 2. Uso del cliente HTTP `RestTemplate`
```java
@Autowired
private RestTemplate restTemplate;
```
- `RestTemplate` es el cliente síncrono oficial de Spring Framework para realizar solicitudes HTTP hacia APIs REST externas.
- El bean de `RestTemplate` fue registrado en `ProyectoclimaApplication.java` con la anotación `@Bean`, lo que permite inyectarlo donde sea necesario mediante `@Autowired`.

### 3. Petición HTTP y Deserialización automática del JSON
```java
ResponseEntity<OpenMeteoResponse> response = restTemplate.getForEntity(climaApiUrl, OpenMeteoResponse.class);
```
- `restTemplate.getForEntity(...)` envía una petición HTTP de tipo `GET` a Open-Meteo.
- **Deserialización con Jackson**: Spring Boot detecta el JSON devuelto por la API y lo convierte automáticamente en una instancia de la clase Java `OpenMeteoResponse`.
- En `OpenMeteoResponse.java`, se utilizan anotaciones de Jackson:
  - `@JsonIgnoreProperties(ignoreUnknown = true)`: Evita errores si la API externa envía campos adicionales que no nos interesan.
  - `@JsonProperty("temperature_2m")`: Mapea el nombre del campo en formato serpiente (`temperature_2m`) a una propiedad Java en formato camelCase (`temperature2m`).

### 4. Traducción de los códigos WMO (`weather_code`)
La API de Open-Meteo utiliza los estándares internacionales de la **WMO (World Meteorological Organization)**, que identifican el estado del tiempo mediante números enteros (`weather_code`):
- `0`: Cielo totalmente despejado.
- `1`, `2`, `3`: Parcialmente nublado / Nublado.
- `45`, `48`: Niebla o neblina.
- `51` a `55`: Lloviznas de diferente intensidad.
- `61` a `65`: Lluvias moderadas a fuertes.
- `80` a `82`: Chaparrones o chubascos.
- `95` a `99`: Tormentas eléctricas severas.

El método privado `traducirCodigoClima(Integer code)` en `ClimaService` utiliza un `switch` para transformar esos números en descripciones amigables en español ("Cielo despejado", "Chaparrones dispersos", "Tormenta eléctrica", etc.).

### 5. Asignación de Iconos Visuales y Emojis
`ClimaService` cuenta con dos métodos de apoyo:
- `obtenerIconoBootstrap(code)`: Determina la clase CSS de Bootstrap Icons correspondiente al código (por ejemplo: `bi bi-sun-fill text-warning`).
- `obtenerIconoEmoji(code)`: Determina el emoji representativo (por ejemplo: `☀️`, `⛅`, `🌧️`).

### 6. Formateo de Fecha y Hora
La API devuelve el tiempo en formato ISO 8601 (por ejemplo: `2026-11-11T21:30`). El método `formatearFechaHora(isoTime)` lo procesa para mostrarlo en formato tradicional argentino: `11/11/2026 21:30 hs`.

### 7. Manejo de Errores
Si la API externa responde con un código distinto a 2xx o no devuelve contenido, `ClimaService` lanza una excepción descriptiva `RuntimeException`. En `ClimaController`, dicha excepción es capturada mediante un bloque `try-catch`, agregando un mensaje de advertencia al modelo (`model.addAttribute("error", ...)`) para que la página web no se caiga y le muestre una alerta roja al usuario.

---

## ☀️ ¿De dónde salen las imágenes del sol, nubes y lluvia? ¿Son caracteres ASCII?

### ❌ ¿Son ASCII? **NO**
- **ASCII estándar** solo comprende 128 caracteres (del 0 al 127). Fue creado en la década de 1960 para teletipos en inglés e incluye únicamente:
  - Letras en inglés (`A-Z`, `a-z`)
  - Dígitos (`0-9`)
  - Signos de puntuación (`.`, `,`, `!`, `?`, etc.)
  - Caracteres de control (`\n`, `\t`, etc.)
- En ASCII **no existen** símbolos de soles, nubes ni colores. (Lo que a veces se llama "arte ASCII" son dibujos hechos combinando caracteres normales como `(o.O)` o `_/\_`).

---

### ✅ De dónde salen realmente en este proyecto:

En este proyecto se utilizan **dos fuentes visuales modernas distintas**:

#### 1. Bootstrap Icons (Iconografía Vectorial SVG / WebFont)
En el archivo `clima.html`, en el `<head>`, se incluye la librería oficial de Bootstrap Icons desde su CDN:
```html
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
```
Cuando en la página se escribe:
```html
<i th:class="${clima.iconoBootstrap}"></i>
```
Spring y Thymeleaf renderizan por ejemplo:
```html
<i class="bi bi-sun-fill text-warning weather-icon-large"></i>
```
- **¿Qué es?**: Es una **fuente web tipográfica vectorial (WebFont / SVG)**.
- **Cómo funciona**: La librería define una hoja de estilos CSS donde la clase `bi-sun-fill` dibuja un sol vectorial matemáticamente trazado en la pantalla.
- **Ventajas**: Al ser vectorial, no pierde calidad al agrandarlo (se ve perfectamente nítido en pantallas 4K o celulares), se le puede aplicar tamaño con CSS (`font-size: 5rem`) y color con las clases de utilidad de Bootstrap (`text-warning` para amarillo, `text-primary` para azul de lluvia, etc.).

#### 2. Emojis de Unicode (UTF-8)
En `ClimaService.java` se utilizan símbolos como:
- Sol: `☀️`
- Parcialmente nublado: `⛅`
- Nube: `☁️`
- Lluvia: `🌧️`
- Tormenta: `⛈️`

- **¿Qué son?**: Son caracteres del estándar universal **Unicode** codificados en **UTF-8**.
- **Cómo funciona**: Del mismo modo que el número binario `65` representa la letra `A`, en Unicode:
  - `U+2600` representa el Sol (`☀️`)
  - `U+26C5` representa el Sol detrás de una nube (`⛅`)
  - `U+1F327` representa la Nube con lluvia (`🌧️`)
- **Quién los dibuja**: El propio sistema operativo del usuario (Windows 10/11 usa la tipografía *Segoe UI Emoji*, Android usa *Noto Color Emoji*, iOS/Mac usa *Apple Color Emoji*). El navegador reconoce el código Unicode y dibuja el dibujo a todo color nativamente, sin necesidad de descargar ninguna imagen externa `.png` ni `.jpg`.

---

## 🧪 Pruebas con Bruno API Client

El proyecto incluye la carpeta `bruno/` configurada como una colección oficial de **Bruno** (la alternativa moderna y ligera a Postman).

### Peticiones configuradas en la colección:
1. **`Obtener Clima CABA (JSON API)`**:
   - Método: `GET`
   - URL: `{{baseUrl}}/api/clima` (evalúa a `http://localhost:8080/api/clima`)
   - Respuesta esperada: Objeto JSON con los datos meteorológicos procesados.
2. **`Obtener Clima CABA (Vista HTML)`**:
   - Método: `GET`
   - URL: `{{baseUrl}}/clima` (evalúa a `http://localhost:8080/clima`)
   - Respuesta esperada: Código HTML completo de la vista con Bootstrap y Thymeleaf.
3. **`API Externa Open-Meteo Directa`**:
   - Método: `GET`
   - URL: Consulta directamente a Open-Meteo con las coordenadas de CABA para comparar los datos crudos con los datos transformados por nuestro servicio.

### Cómo importar la colección en Bruno:
1. Abre la aplicación **Bruno**.
2. Haz clic en **Open Collection** (o *Abrir Colección*).
3. Selecciona la carpeta `proyectoclima/bruno` (o `bruno` en la raíz).
4. ¡Listo! Verás las tres peticiones organizadas y listas para ejecutar haciendo clic en **Send**.

---

## 🚀 Cómo Ejecutar la Aplicación

1. Abrir una terminal en el directorio del proyecto:
   ```bash
   cd proyectoclima
   ```

2. Ejecutar con Maven:
   ```bash
   mvn spring-boot:run
   ```
   *(O en Windows usando el wrapper: `.\mvnw.cmd spring-boot:run`)*

3. Abrir el navegador en:
   👉 **http://localhost:8080** (o **http://localhost:8080/clima**)
