package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.repository.IAutoRepository;

@Service
public class AutoService {

    @Autowired
    private IAutoRepository autoRepo;

    public List<Auto> getAutos() {
        return autoRepo.findAll();
    }

    public void saveAuto(Auto auto) {
        autoRepo.save(auto);
    }

    public void deleteAuto(Long id) {
        autoRepo.deleteById(id);
    }

    public Auto findAuto(Long id) {
        return autoRepo.findById(id).orElse(null);
    }

    public void editAuto(Long idOriginal, Long idNueva, String nuevaMarca, Double nuevoPrecio) {
        Auto auto = this.findAuto(idOriginal);

        if (auto != null) {
            if (idNueva != null) {
                auto.setId(idNueva);
            }
            if (nuevaMarca != null) {
                auto.setMarca(nuevaMarca);
            }
            if (nuevoPrecio != null) {
                auto.setPrecio(nuevoPrecio);
            }

            this.saveAuto(auto);
        }
    }
}
