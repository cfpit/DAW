package ar.edu.centro8.desarrollo.proyectojpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;

@Repository
public interface IAutoRepository extends JpaRepository<Auto, Long> {

}
