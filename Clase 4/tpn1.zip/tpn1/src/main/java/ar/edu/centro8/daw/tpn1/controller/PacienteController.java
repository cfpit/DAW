package ar.edu.centro8.daw.tpn1.controller;

import ar.edu.centro8.daw.tpn1.model.Paciente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class PacienteController {
    
    private List<Paciente> pacientes;
    
    public PacienteController() {
        pacientes = new ArrayList<>();
        inicializarPacientes();
    }
    
    private void inicializarPacientes() {
        pacientes.add(new Paciente(1L, "12345678", "Juan", "Pérez", LocalDate.of(1990, 5, 15)));
        pacientes.add(new Paciente(2L, "87654321", "María", "González", LocalDate.of(2010, 8, 22)));
        pacientes.add(new Paciente(3L, "11223344", "Carlos", "Rodríguez", LocalDate.of(1985, 12, 3)));
        pacientes.add(new Paciente(4L, "44332211", "Ana", "López", LocalDate.of(2008, 3, 10)));
        pacientes.add(new Paciente(5L, "55667788", "Luis", "Martínez", LocalDate.of(1975, 7, 28)));
        pacientes.add(new Paciente(6L, "99887766", "Sofía", "García", LocalDate.of(2012, 11, 5)));
        pacientes.add(new Paciente(7L, "13579246", "Pedro", "Fernández", LocalDate.of(1995, 1, 18)));
        pacientes.add(new Paciente(8L, "24681357", "Laura", "Silva", LocalDate.of(2009, 6, 14)));
    }
    
    // Endpoint a: Listar todos los pacientes
    // http://localhost:8080/pacientes
    @GetMapping("/pacientes")
    public List<Paciente> listarTodosLosPacientes() {
        return pacientes;
    }
    
    // Endpoint b: Listar solo pacientes menores de edad
    // http://localhost:8080/pacientes/menores
    @GetMapping("/pacientes/menores")
    public List<Paciente> listarPacientesMenores() {
        LocalDate fechaActual = LocalDate.now();
        
        return pacientes.stream()
                .filter(paciente -> calcularEdad(paciente.getFechaNacimiento(), fechaActual) < 18)
                .collect(Collectors.toList());
    }
    
    // Método auxiliar para calcular la edad
    private int calcularEdad(LocalDate fechaNacimiento, LocalDate fechaActual) {
        return Period.between(fechaNacimiento, fechaActual).getYears();
    }
}
