package herencia;

public class Test {
    public static void main(String[] args) throws Exception {
        //creo un auto y un auto de carrera
        Auto auto = new Auto("Ford", 50);
        AutoCarrera autoDeCarrera = new AutoCarrera("Ferrari", 100,"Aleron de fibra de carbono");

        auto.acelerar();
        autoDeCarrera.acelerar();

        System.out.println(auto);
        System.out.println(autoDeCarrera);
    }
}
