package ar.edu.centro8.daw.tpn1.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Plato {
    
    private int numeroPlato;
    private String nombre;
    private double precio;
    private String descripcion;
    
}
