# Proyecto Spring Boot + JPA + Thymeleaf (Gestión de Autos)

Aplicación web desarrollada con **Spring Boot**, **Spring Data JPA**, **MySQL** y el motor de plantillas **Thymeleaf** para la gestión (CRUD) de vehículos.

---

## 🛠️ Configuración Automática de la Base de Datos

En el archivo [`application.properties`](file:///src/main/resources/application.properties), la URL JDBC incluye el parámetro **`createDatabaseIfNotExist=true`**:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/proyecto_auto?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
```

- **¿Qué hace?** Si la base de datos `proyecto_auto` no existe en el servidor MySQL al momento de levantar la aplicación, el driver de MySQL la creará automáticamente.
- **Creación de tablas:** Gracias a `spring.jpa.hibernate.ddl-auto=update`, Hibernate genera o actualiza las tablas (`auto`) automáticamente a partir de las entidades JPA.

---

## 📖 Explicación Detallada del Código Thymeleaf

Thymeleaf es un motor de plantillas Java del lado del servidor (Server-Side Rendering). Permite procesar HTML válido agregándole atributos especiales con el prefijo `th:`.

A continuación se detalla cada vista, elemento y expresión utilizada en el proyecto:

---

### 1. Declaración del Namespace

En la etiqueta `<html>` de ambas plantillas ([`index.html`](file:///src/main/resources/templates/index.html) y [`editar.html`](file:///src/main/resources/templates/editar.html)):

```html
<html xmlns:th="http://www.thymeleaf.org">
```
- Define el espacio de nombres (namespace) `th:`. Habilita el autocompletado y validación de las directivas de Thymeleaf en el editor o navegador sin romper la estructura HTML estándar.

---

### 2. Sintaxis de Expresiones Thymeleaf utilizadas

| Expresión | Tipo | Ejemplo en el proyecto | Descripción |
| :--- | :--- | :--- | :--- |
| **`${...}`** | Expresión de variable (Spring EL) | `${autos}`, `${mensaje}`, `${auto.marca}` | Obtiene variables colocadas en el objeto `Model` o `RedirectAttributes` desde el controlador. |
| **`*{...}`** | Expresión de selección (Asterisco) | `*{marca}`, `*{precio}`, `*{id}` | Evalúa propiedades relativas al objeto previamente seleccionado con `th:object`. |
| **`@{...}`** | Expresión de enlaces/URLs | `@{/autos/crear}`, `@{/autos/editar/{id}(id=...)}` | Construye URLs dinámicas resolviendo automáticamente el context-path de la aplicación y parámetros de ruta o query. |
| **`#...`** | Objetos de utilidad de Thymeleaf | `#lists.isEmpty(...)`, `#numbers.formatDecimal(...)` | Métodos auxiliares integrados para colecciones, números, fechas, cadenas, etc. |

---

### 3. Vista Principal: `index.html`

#### A. Notificaciones y Mensajes Flash (`th:if`, `th:text`, `th:class`)

```html
<div th:if="${mensaje}" th:text="${mensaje}" 
     th:class="${exito} ? 'alert alert-success' : 'alert alert-danger'" 
     class="alert" role="alert">
</div>
```

- **`th:if="${mensaje}"`**: Renderizado condicional. El `<div>` solo se incluirá en el DOM si el atributo `mensaje` existe y no es nulo/vacío.
- **`th:text="${mensaje}"`**: Reemplaza el texto interno del `<div>` escapando caracteres especiales para prevenir ataques XSS. Muestra el texto enviado desde el controlador (por ejemplo: *"El auto fue creado correctamente"*).
- **`th:class="..."`**: Evalúa una expresión ternaria condicional: si `exito` es `true`, aplica la clase CSS `'alert alert-success'`, de lo contrario aplica `'alert alert-danger'`.

---

#### B. Formulario de Alta (`th:action`, `th:object`, `th:field`)

```html
<form th:action="@{/autos/crear}" method="post" th:object="${nuevoAuto}">
    <div class="mb-3">
        <label for="marca" class="form-label">Marca:</label>
        <input type="text" class="form-control" id="marca" th:field="*{marca}" required>
    </div>
    <div class="mb-3">
        <label for="precio" class="form-label">Precio:</label>
        <input type="number" class="form-control" id="precio" th:field="*{precio}" step="0.01" required>
    </div>
    <button type="submit" class="btn btn-primary">Guardar Auto</button>
</form>
```

- **`th:action="@{/autos/crear}"`**: Genera la URL de destino para el envío del formulario HTTP POST.
- **`th:object="${nuevoAuto}"`**: Vincula el formulario a una instancia del modelo `Auto` provista por el controlador en el modelo (`model.addAttribute("nuevoAuto", new Auto())`).
- **`th:field="*{marca}"`**: Vinculación bidireccional (two-way binding):
  - Genera automáticamente los atributos HTML `id="marca"`, `name="marca"` y `value=""`.
  - Cuando se envía el formulario, Spring mapea automáticamente los valores recibidos en las propiedades correspondientes de la entidad `Auto`.

---

#### C. Control de Lista Vacía (`th:if` vs `th:unless` y `#lists.isEmpty`)

```html
<div th:if="${#lists.isEmpty(autos)}" class="alert alert-info">
    No hay autos registrados.
</div>
<div th:unless="${#lists.isEmpty(autos)}">
    <!-- Tabla con autos -->
</div>
```

- **`#lists.isEmpty(autos)`**: Objeto de utilidad que evalúa si la colección `autos` está vacía o es nula.
- **`th:if`**: Renderiza el bloque de alerta únicamente si la lista está vacía.
- **`th:unless`**: Actúa como un *negado* (`if not`). Renderiza la tabla solo cuando la lista **NO** está vacía.

---

#### D. Iteración de Filas y Formato (`th:each`, `#numbers.formatDecimal`)

```html
<tr th:each="auto : ${autos}">
    <td th:text="${auto.id}"></td>
    <td th:text="${auto.marca}"></td>
    <td th:text="${'$' + #numbers.formatDecimal(auto.precio, 0, 2)}"></td>
    <td>
        <a th:href="@{/autos/editar/{id}(id=${auto.id})}" class="btn btn-warning btn-sm">Editar</a>
        <a th:href="@{/autos/eliminar/{id}(id=${auto.id})}" class="btn btn-danger btn-sm"
           onclick="return confirm('¿Estás seguro de que deseas eliminar este auto?')">Eliminar</a>
    </td>
</tr>
```

- **`th:each="auto : ${autos}"`**: Estructura de bucle `for-each`. Repite la etiqueta `<tr>` por cada elemento contenido en la lista `${autos}`.
- **`th:text="${auto.id}"`** / **`th:text="${auto.marca}"`**: Accede a los getters correspondientes (`getId()`, `getMarca()`) de la entidad e inserta su valor como texto.
- **`${'$' + #numbers.formatDecimal(auto.precio, 0, 2)}`**: Utiliza el formateador numérico para presentar el precio con un mínimo de 0 dígitos enteros y 2 posiciones decimales fijas precedidas por el signo `$`.
- **`th:href="@{/autos/editar/{id}(id=${auto.id})}"`**: Genera un hipervínculo con variable de trayectoria (*path variable*). Si el id es 5, produce dinámicamente `/autos/editar/5`.

---

### 4. Vista de Edición: `editar.html`

#### A. Campo Oculto para Identificador (`<input type="hidden">`)

```html
<form th:action="@{/autos/actualizar}" method="post" th:object="${auto}">
    <input type="hidden" th:field="*{id}">
    
    <div class="mb-3">
        <label for="marca" class="form-label">Marca:</label>
        <input type="text" class="form-control" id="marca" th:field="*{marca}" required>
    </div>
    ...
```

- **`<input type="hidden" th:field="*{id}">`**: Thymeleaf inyecta el ID actual del auto que se está editando en un campo oculto (`value="5"`). Al presionar *Actualizar*, Spring recibe el ID para saber qué registro modificar en la base de datos.
- **Poblado automático de campos**: A diferencia de la pantalla de creación, aquí `th:field="*{marca}"` y `th:field="*{precio}"` precargan los valores existentes en los inputs para que el usuario pueda modificarlos.

#### B. Botón Cancelar con enlace contextual

```html
<a th:href="@{/}" class="btn btn-secondary">Cancelar</a>
```
- Redirige al usuario a la raíz (`/`) de forma limpia y relativa a la raíz de la aplicación.

