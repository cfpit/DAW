package ar.edu.centro8.desarrollo.proyectojpa.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;
import ar.edu.centro8.desarrollo.proyectojpa.service.AutoService;

@RestController
@CrossOrigin(origins = "*", methods= {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
public class AutoController {

    @Autowired
    private AutoService autoServ;

    @GetMapping("/autos/traer")
    public List<Auto> getAutos() {
        return autoServ.getAutos();
    }

    @GetMapping("/autos/traer/{id}")
    public Auto findAuto(@PathVariable Long id) {
        return autoServ.findAuto(id);
    }

    @PostMapping("/autos/crear")
    public String saveAuto(@RequestBody Auto auto) {
        autoServ.saveAuto(auto);
        return "El auto fue creado correctamente";
    }

    @DeleteMapping("/autos/borrar/{id}")
    public String deleteAuto(@PathVariable Long id) {
        autoServ.deleteAuto(id);
        return "El auto fue eliminado correctamente";
    }

    @PutMapping("/autos/editar/{id_original}")
    public Auto editAuto(@PathVariable Long id_original,
            @RequestParam(required = false, name = "id") Long nuevaId,
            @RequestParam(required = false, name = "marca") String nuevaMarca,
            @RequestParam(required = false, name = "precio") Double nuevoPrecio) {

        autoServ.editAuto(id_original, nuevaId, nuevaMarca, nuevoPrecio);

        Long searchId = (nuevaId != null) ? nuevaId : id_original;
        return autoServ.findAuto(searchId);
    }
}
