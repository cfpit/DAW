package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Dolar;
import ar.edu.centro8.desarrollo.proyectosbon2.service.DolarService;

@Controller
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class DolarController {

    @Autowired
    private DolarService dolarService;

    // Endpoint REST que retorna JSON
    @GetMapping("/api/dolar")
    @ResponseBody
    public Dolar obtenerDolarAPI() {
        return dolarService.obtenerDolar();
    }

    // Endpoint que retorna la vista Thymeleaf
    @GetMapping("/dolar")
    public String obtenerDolarVista(Model model) {
        try {
            Dolar dolar = dolarService.obtenerDolar();
            model.addAttribute("dolar", dolar);
        } catch (Exception e) {
            model.addAttribute("error", "Error al obtener la información del dólar: " + e.getMessage());
            model.addAttribute("dolar", new Dolar());
        }
        return "dolar";
    }
    
}
