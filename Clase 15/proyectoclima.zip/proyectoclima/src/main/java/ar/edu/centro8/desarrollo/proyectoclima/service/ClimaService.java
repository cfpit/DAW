package ar.edu.centro8.desarrollo.proyectoclima.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import ar.edu.centro8.desarrollo.proyectoclima.model.Clima;
import ar.edu.centro8.desarrollo.proyectoclima.model.OpenMeteoResponse;

@Service
public class ClimaService {

    @Value("${clima.api.url}")
    private String climaApiUrl;

    @Autowired
    private RestTemplate restTemplate;

    public Clima obtenerClimaCaba() {
        ResponseEntity<OpenMeteoResponse> response = restTemplate.getForEntity(climaApiUrl, OpenMeteoResponse.class);

        if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
            OpenMeteoResponse data = response.getBody();
            OpenMeteoResponse.CurrentWeather current = data.getCurrent();

            if (current == null) {
                throw new RuntimeException("No se recibieron datos actuales del clima.");
            }

            Integer code = current.getWeatherCode();

            Clima clima = new Clima();
            clima.setCiudad("Ciudad Autónoma de Buenos Aires (CABA)");
            clima.setTemperatura(current.getTemperature2m());
            clima.setSensacionTermica(current.getApparentTemperature());
            clima.setHumedad(current.getRelativeHumidity2m());
            clima.setViento(current.getWindSpeed10m());
            clima.setPrecipitacion(current.getPrecipitation());
            clima.setDescripcion(traducirCodigoClima(code));
            clima.setIconoBootstrap(obtenerIconoBootstrap(code));
            clima.setIconoEmoji(obtenerIconoEmoji(code));
            clima.setHoraActualizacion(formatearFechaHora(current.getTime()));

            return clima;
        } else {
            throw new RuntimeException("Error al consultar la API del clima de CABA");
        }
    }

    private String formatearFechaHora(String isoTime) {
        if (isoTime == null) return "No disponible";
        try {
            // Convierte "2026-11-11T21:15" en "11/11/2026 21:15 hs"
            if (isoTime.contains("T")) {
                String[] parts = isoTime.split("T");
                String[] ymd = parts[0].split("-");
                return ymd[2] + "/" + ymd[1] + "/" + ymd[0] + " " + parts[1] + " hs";
            }
            return isoTime;
        } catch (Exception e) {
            return isoTime;
        }
    }

    private String traducirCodigoClima(Integer code) {
        if (code == null) return "Condición no disponible";
        switch (code) {
            case 0: return "Cielo despejado";
            case 1: return "Principalmente despejado";
            case 2: return "Parcialmente nublado";
            case 3: return "Nublado";
            case 45: return "Niebla";
            case 48: return "Niebla con escarcha";
            case 51: return "Llovizna ligera";
            case 53: return "Llovizna moderada";
            case 55: return "Llovizna densa";
            case 56: case 57: return "Llovizna helada";
            case 61: return "Lluvia ligera";
            case 63: return "Lluvia moderada";
            case 65: return "Lluvia fuerte";
            case 66: case 67: return "Lluvia helada";
            case 71: return "Nevada ligera";
            case 73: return "Nevada moderada";
            case 75: return "Nevada fuerte";
            case 77: return "Granizo fino";
            case 80: return "Chaparrones dispersos";
            case 81: return "Chaparrones moderados";
            case 82: return "Chaparrones violentos";
            case 85: case 86: return "Chubascos de nieve";
            case 95: return "Tormenta eléctrica";
            case 96: case 99: return "Tormenta eléctrica con granizo";
            default: return "Tiempo variable";
        }
    }

    private String obtenerIconoBootstrap(Integer code) {
        if (code == null) return "bi bi-cloud-sun text-secondary";
        switch (code) {
            case 0: return "bi bi-sun-fill text-warning";
            case 1: return "bi bi-cloud-sun-fill text-warning";
            case 2: return "bi bi-cloud-sun text-secondary";
            case 3: return "bi bi-clouds-fill text-secondary";
            case 45: case 48: return "bi bi-cloud-haze-fill text-muted";
            case 51: case 53: case 55: case 56: case 57: return "bi bi-cloud-drizzle-fill text-info";
            case 61: case 63: case 65: case 66: case 67: return "bi bi-cloud-rain-heavy-fill text-primary";
            case 71: case 73: case 75: case 77: case 85: case 86: return "bi bi-snow text-info";
            case 80: case 81: case 82: return "bi bi-cloud-rain-fill text-primary";
            case 95: case 96: case 99: return "bi bi-cloud-lightning-rain-fill text-danger";
            default: return "bi bi-cloud-fill text-secondary";
        }
    }

    private String obtenerIconoEmoji(Integer code) {
        if (code == null) return "🌤️";
        switch (code) {
            case 0: return "☀️";
            case 1: return "🌤️";
            case 2: return "⛅";
            case 3: return "☁️";
            case 45: case 48: return "🌫️";
            case 51: case 53: case 55: case 56: case 57: return "🌦️";
            case 61: case 63: case 65: case 66: case 67: return "🌧️";
            case 71: case 73: case 75: case 77: case 85: case 86: return "❄️";
            case 80: case 81: case 82: return "🌧️";
            case 95: case 96: case 99: return "⛈️";
            default: return "⛅";
        }
    }
}
