package ar.edu.centro8.daw.tpn1.controller;

import ar.edu.centro8.daw.tpn1.model.Plato;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class PlatoController {

    private List<Plato> menu = new ArrayList<>();
    
    public PlatoController() {
        menu.add(new Plato(1, "Pizza Margherita", 850.00, "Pizza clásica con salsa de tomate, mozzarella y albahaca fresca"));
        menu.add(new Plato(2, "Hamburguesa Completa", 950.00, "Hamburguesa de carne con lechuga, tomate, cebolla, queso y papas fritas"));
        menu.add(new Plato(3, "Ensalada César", 650.00, "Ensalada fresca con pollo grillado, crutones, parmesano y aderezo césar"));
        menu.add(new Plato(4, "Milanesa Napolitana", 1200.00, "Milanesa de ternera con jamón, queso, salsa de tomate y papas fritas"));
        menu.add(new Plato(5, "Pasta Carbonara", 780.00, "Spaghetti con salsa carbonara, panceta, huevo y queso parmesano"));
    }
    
    
    //endpoint: http://localhost:8080/plato?numeroPlato=1
    @GetMapping("/plato")
    public ResponseEntity<?> consultarPlato(@RequestParam int numeroPlato) {
        for (Plato plato : menu) {
            if (plato.getNumeroPlato() == numeroPlato) {
                return ResponseEntity.ok(plato);
            }
        }
        // Si no se encuentra el plato, devolver mensaje de error con código 404
        return ResponseEntity.status(404).body("Plato no encontrado. Los números de plato disponibles son del 1 al 5.");
    }
}
