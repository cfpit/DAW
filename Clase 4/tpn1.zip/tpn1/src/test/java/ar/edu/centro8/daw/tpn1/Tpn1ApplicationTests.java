package ar.edu.centro8.daw.tpn1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
