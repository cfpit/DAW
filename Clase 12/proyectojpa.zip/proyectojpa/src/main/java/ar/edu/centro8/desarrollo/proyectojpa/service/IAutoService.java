package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;
import ar.edu.centro8.desarrollo.proyectojpa.model.Auto;

public interface IAutoService {
    //método para traer a todos los autos
    //lectura
    public List<Auto> getAutos();

    //alta
    public void saveAuto(Auto auto);

    //baja
    public void deleteAuto(Long id);

    //lectura de un solo objeto
    public Auto findAuto(Long id);

    //edición/modificación
    public void editAuto(Long idOriginal, Long idNueva,
                         String nuevaMarca,
                         double nuevoPrecio);
}
