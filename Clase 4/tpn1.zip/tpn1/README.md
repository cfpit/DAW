# Trabajo Práctico Nro. 1 - APIs con Spring Boot

Documentación y guía de pruebas para los ejercicios del **Trabajo Práctico Nro. 1** desarrollado con **Spring Boot**, **Java 21** y **Lombok**.

---

## 🚀 Requisitos Previos e Instalación

### Requisitos:
* **Java Development Kit (JDK):** Versión 21 o superior.
* **Maven:** (Incluido mediante el wrapper `./mvnw`).
* Cliente HTTP para pruebas: **Postman**, **Bruno** o **cURL**.

### Cómo ejecutar la aplicación:
Abre una terminal en la raíz del proyecto y ejecuta el siguiente comando:

```bash
# En Linux/macOS
./mvnw spring-boot:run

# En Windows (PowerShell / Command Prompt)
.\mvnw.cmd spring-boot:run
```

La aplicación se ejecutará en: `http://localhost:8080`

---

## 📦 Colección de Pruebas (`coleccion.json`)

El proyecto incluye el archivo [`coleccion.json`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/daw/Nueva%20carpeta/tpn1/coleccion.json) en la raíz. Contiene todos los endpoints configurados y listos para importar.

### Importar en Postman:
1. Abre **Postman**.
2. Haz clic en **Import** (arriba a la izquierda).
3. Selecciona el archivo `coleccion.json`.
4. ¡Listo! Se creará la colección **TPN1 - APIs SpringBoot** con todas las solicitudes de prueba.

### Importar en Bruno:
1. Abre **Bruno**.
2. Selecciona **Import Collection**.
3. Elige el formato **Postman Collection (v2.1.0)**.
4. Selecciona el archivo `coleccion.json` y confirma la importación.

---

## 📋 Listado de Endpoints por Ejercicio

---

### 1. Ejercicio Nº 1 – Conversión de Unidades (Galones a Litros)
Convierte una cantidad dada de galones a litros utilizando el factor de conversión $1 \text{ galón} = 3.78541 \text{ litros}$.

* **Endpoint:** `/conversion`
* **Método HTTP:** `GET`
* **Parámetros de consulta (Query Params):**
  * `galones` (decimal, obligatorio): Cantidad de galones a convertir.

#### Ejemplos de Pruebas:

* **cURL:**
  ```bash
  curl -X GET "http://localhost:8080/conversion?galones=5.5"
  ```

* **Postman:**
  * **Method:** `GET`
  * **URL:** `http://localhost:8080/conversion`
  * **Params:** `galones` = `5.5`

* **Bruno (`.bru`):**
  ```text
  meta {
    name: Ejercicio 1 - Conversion Galones a Litros
    type: http
    seq: 1
  }

  get {
    url: http://localhost:8080/conversion?galones=5.5
    body: none
    auth: none
  }

  params:query {
    galones: 5.5
  }
  ```

* **Respuesta Esperada (`200 OK`):**
  ```text
  5.50 galones equivalen a 20.82 litros
  ```

---

### 2. Ejercicio Nº 2 – Promedio de Notas
Recibe 3 notas de una materia mediante `@RequestParam` y calcula el promedio de las mismas.

* **Endpoint:** `/promedio`
* **Método HTTP:** `GET`
* **Parámetros de consulta (Query Params):**
  * `nota1` (decimal): Primera nota.
  * `nota2` (decimal): Segunda nota.
  * `nota3` (decimal): Tercera nota.

#### Ejemplos de Pruebas:

* **cURL:**
  ```bash
  curl -X GET "http://localhost:8080/promedio?nota1=8.5&nota2=7.0&nota3=9.2"
  ```

* **Postman:**
  * **Method:** `GET`
  * **URL:** `http://localhost:8080/promedio`
  * **Params:** 
    * `nota1` = `8.5`
    * `nota2` = `7.0`
    * `nota3` = `9.2`

* **Bruno (`.bru`):**
  ```text
  meta {
    name: Ejercicio 2 - Promedio de Notas
    type: http
    seq: 2
  }

  get {
    url: http://localhost:8080/promedio?nota1=8.5&nota2=7.0&nota3=9.2
    body: none
    auth: none
  }

  params:query {
    nota1: 8.5
    nota2: 7.0
    nota3: 9.2
  }
  ```

* **Respuesta Esperada (`200 OK`):**
  ```text
  El promedio de las notas 8.50, 7.00 y 9.20 es: 8.23
  ```

---

### 3. Ejercicio Nº 3 – Restaurante (Consulta de Platos)
Consulta los datos de un plato del menú (almacenado en una `ArrayList`) según el número de plato ingresado.

* **Endpoint:** `/plato`
* **Método HTTP:** `GET`
* **Parámetros de consulta (Query Params):**
  * `numeroPlato` (entero): Número del plato a consultar (del 1 al 5).

#### Ejemplos de Pruebas:

#### Caso 1: Plato Existente (ej. Plato 1)
* **cURL:**
  ```bash
  curl -X GET "http://localhost:8080/plato?numeroPlato=1"
  ```

* **Postman:**
  * **Method:** `GET`
  * **URL:** `http://localhost:8080/plato`
  * **Params:** `numeroPlato` = `1`

* **Bruno (`.bru`):**
  ```text
  meta {
    name: Ejercicio 3 - Consultar Plato Existente
    type: http
    seq: 3
  }

  get {
    url: http://localhost:8080/plato?numeroPlato=1
    body: none
    auth: none
  }

  params:query {
    numeroPlato: 1
  }
  ```

* **Respuesta Esperada (`200 OK`):**
  ```json
  {
    "numeroPlato": 1,
    "nombre": "Pizza Margherita",
    "precio": 850.0,
    "descripcion": "Pizza clásica con salsa de tomate, mozzarella y albahaca fresca"
  }
  ```

#### Caso 2: Plato No Existente (ej. Plato 99)
* **cURL:**
  ```bash
  curl -X GET "http://localhost:8080/plato?numeroPlato=99"
  ```

* **Respuesta Esperada (`404 Not Found`):**
  ```text
  Plato no encontrado. Los números de plato disponibles son del 1 al 5.
  ```

---

### 4. Ejercicio Nº 4 – Odontólogo (Gestión de Pacientes)

#### a) Listado Completo de Pacientes
Devuelve la lista total de pacientes registrados.

* **Endpoint:** `/pacientes`
* **Método HTTP:** `GET`

* **cURL:**
  ```bash
  curl -X GET "http://localhost:8080/pacientes"
  ```

* **Postman / Bruno:**
  * **Method:** `GET`
  * **URL:** `http://localhost:8080/pacientes`

* **Respuesta Esperada (`200 OK`):**
  ```json
  [
    {
      "id": 1,
      "dni": "12345678",
      "nombre": "Juan",
      "apellido": "Pérez",
      "fechaNacimiento": "1990-05-15"
    },
    {
      "id": 2,
      "dni": "87654321",
      "nombre": "María",
      "apellido": "González",
      "fechaNacimiento": "2010-08-22"
    },
    ...
  ]
  ```

---

#### b) Pacientes Menores de Edad
Filtra la lista y devuelve únicamente a los pacientes menores de 18 años calculando la edad con `LocalDate.now()` y `Period.between`.

* **Endpoint:** `/pacientes/menores`
* **Método HTTP:** `GET`

* **cURL:**
  ```bash
  curl -X GET "http://localhost:8080/pacientes/menores"
  ```

* **Postman / Bruno:**
  * **Method:** `GET`
  * **URL:** `http://localhost:8080/pacientes/menores`

* **Respuesta Esperada (`200 OK`):**
  ```json
  [
    {
      "id": 2,
      "dni": "87654321",
      "nombre": "María",
      "apellido": "González",
      "fechaNacimiento": "2010-08-22"
    },
    {
      "id": 4,
      "dni": "44332211",
      "nombre": "Ana",
      "apellido": "López",
      "fechaNacimiento": "2008-03-10"
    },
    {
      "id": 6,
      "dni": "99887766",
      "nombre": "Sofía",
      "apellido": "García",
      "fechaNacimiento": "2012-11-05"
    },
    {
      "id": 8,
      "dni": "24681357",
      "nombre": "Laura",
      "apellido": "Silva",
      "fechaNacimiento": "2009-06-14"
    }
  ]
  ```

---

### 5. Ejercicio Nº 5 – Estaturas en Básquet
Da de alta una lista de 5 jugadores enviados en el cuerpo JSON (`@RequestBody`) a una base de datos lógica (`ArrayList`) y devuelve el promedio de estatura de los jugadores ingresados.

* **Endpoint:** `/jugadores`
* **Método HTTP:** `POST`
* **Headers:** `Content-Type: application/json`

#### Ejemplos de Pruebas:

* **cURL:**
  ```bash
  curl -X POST "http://localhost:8080/jugadores" \
    -H "Content-Type: application/json" \
    -d '[
      {
        "id": 1,
        "dni": "11111111",
        "nombre": "Michael",
        "apellido": "Jordan",
        "edad": 23,
        "peso": 98.0,
        "estatura": 1.98
      },
      {
        "id": 2,
        "dni": "22222222",
        "nombre": "LeBron",
        "apellido": "James",
        "edad": 22,
        "peso": 113.0,
        "estatura": 2.06
      },
      {
        "id": 3,
        "dni": "33333333",
        "nombre": "Kobe",
        "apellido": "Bryant",
        "edad": 24,
        "peso": 96.0,
        "estatura": 1.98
      },
      {
        "id": 4,
        "dni": "44444444",
        "nombre": "Stephen",
        "apellido": "Curry",
        "edad": 25,
        "peso": 84.0,
        "estatura": 1.88
      },
      {
        "id": 5,
        "dni": "55555555",
        "nombre": "Shaquille",
        "apellido": "O'Neal",
        "edad": 26,
        "peso": 147.0,
        "estatura": 2.16
      }
    ]'
  ```

* **Postman:**
  * **Method:** `POST`
  * **URL:** `http://localhost:8080/jugadores`
  * **Headers:** `Content-Type: application/json`
  * **Body:** `raw` -> `JSON`:
    ```json
    [
      {
        "id": 1,
        "dni": "11111111",
        "nombre": "Michael",
        "apellido": "Jordan",
        "edad": 23,
        "peso": 98.0,
        "estatura": 1.98
      },
      {
        "id": 2,
        "dni": "22222222",
        "nombre": "LeBron",
        "apellido": "James",
        "edad": 22,
        "peso": 113.0,
        "estatura": 2.06
      },
      {
        "id": 3,
        "dni": "33333333",
        "nombre": "Kobe",
        "apellido": "Bryant",
        "edad": 24,
        "peso": 96.0,
        "estatura": 1.98
      },
      {
        "id": 4,
        "dni": "44444444",
        "nombre": "Stephen",
        "apellido": "Curry",
        "edad": 25,
        "peso": 84.0,
        "estatura": 1.88
      },
      {
        "id": 5,
        "dni": "55555555",
        "nombre": "Shaquille",
        "apellido": "O'Neal",
        "edad": 26,
        "peso": 147.0,
        "estatura": 2.16
      }
    ]
    ```

* **Bruno (`.bru`):**
  ```text
  meta {
    name: Ejercicio 5 - Alta Jugadores y Promedio Estatura
    type: http
    seq: 5
  }

  post {
    url: http://localhost:8080/jugadores
    body: json
    auth: none
  }

  headers {
    Content-Type: application/json
  }

  body:json {
    [
      {
        "id": 1,
        "dni": "11111111",
        "nombre": "Michael",
        "apellido": "Jordan",
        "edad": 23,
        "peso": 98.0,
        "estatura": 1.98
      },
      {
        "id": 2,
        "dni": "22222222",
        "nombre": "LeBron",
        "apellido": "James",
        "edad": 22,
        "peso": 113.0,
        "estatura": 2.06
      },
      {
        "id": 3,
        "dni": "33333333",
        "nombre": "Kobe",
        "apellido": "Bryant",
        "edad": 24,
        "peso": 96.0,
        "estatura": 1.98
      },
      {
        "id": 4,
        "dni": "44444444",
        "nombre": "Stephen",
        "apellido": "Curry",
        "edad": 25,
        "peso": 84.0,
        "estatura": 1.88
      },
      {
        "id": 5,
        "dni": "55555555",
        "nombre": "Shaquille",
        "apellido": "O'Neal",
        "edad": 26,
        "peso": 147.0,
        "estatura": 2.16
      }
    ]
  }
  ```

* **Respuesta Esperada (`200 OK`):**
  ```text
  Se dieron de alta 5 jugadores. Promedio de estatura: 2.01 metros
  ```

---

## 🛠️ Resumen de los Endpoints

| Ejercicio | Descripción | Método | Endpoint | Parámetros / Body |
|---|---|---|---|---|
| **Ejercicio 1** | Conversión Galones a Litros | `GET` | `/conversion` | `galones` (Query Param) |
| **Ejercicio 2** | Promedio de 3 Notas | `GET` | `/promedio` | `nota1`, `nota2`, `nota3` (Query Params) |
| **Ejercicio 3** | Consulta de Plato del Menú | `GET` | `/plato` | `numeroPlato` (Query Param) |
| **Ejercicio 4a** | Listar Todos los Pacientes | `GET` | `/pacientes` | Ninguno |
| **Ejercicio 4b** | Listar Pacientes Menores | `GET` | `/pacientes/menores` | Ninguno |
| **Ejercicio 5** | Alta de 5 Jugadores y Promedio | `POST` | `/jugadores` | JSON Array en `@RequestBody` |

---
