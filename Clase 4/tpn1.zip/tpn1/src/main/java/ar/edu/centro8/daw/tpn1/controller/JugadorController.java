package ar.edu.centro8.daw.tpn1.controller;

import ar.edu.centro8.daw.tpn1.model.Jugador;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class JugadorController {
    
    // Base de datos lógica representada por ArrayList
    private List<Jugador> jugadores = new ArrayList<>();
    
    // Endpoint POST para dar de alta 5 jugadores y obtener promedio de estatura
    // http://localhost:8080/jugadores
    @PostMapping("/jugadores")
    public String darDeAltaJugadores(@RequestBody List<Jugador> nuevosJugadores) {
        
        // Dar de alta los jugadores en la "base de datos" (ArrayList)
        jugadores.addAll(nuevosJugadores);
        
        // Calcular el promedio de estatura
        double suma = 0;
        for (Jugador jugador : nuevosJugadores) {
            suma += jugador.getEstatura();
        }
        double promedio = suma / nuevosJugadores.size();
        
        return String.format("Se dieron de alta %d jugadores. Promedio de estatura: %.2f metros", 
                           nuevosJugadores.size(), promedio);
    }
}
