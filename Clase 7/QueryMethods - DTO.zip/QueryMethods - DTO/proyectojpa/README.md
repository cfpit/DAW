# Proyecto JPA - Arquitectura por Capas con Spring Boot

Este proyecto es una aplicación **Spring Boot** desarrollada para demostrar las mejores prácticas en el diseño de APIs RESTful utilizando **Spring Data JPA**, la arquitectura de n-capas (*Controller, Service, Repository, Model*) y el patrón **DTO (Data Transfer Object)**.

---

## 📐 Arquitectura del Proyecto

La aplicación sigue una **Arquitectura en Capas (Layered Architecture)**, garantizando una alta cohesión, un bajo acoplamiento y la separación de responsabilidades (*Separation of Concerns*).

```
   [ Cliente HTTP / Frontend ]
               │
               ▼
   ┌───────────────────────┐
   │      CONTROLLER       │  <-- Recibe peticiones HTTP, valida entradas y responde
   └───────────┬───────────┘
               │ Usa DTOs (Request / Response)
               ▼
   ┌───────────────────────┐
   │        SERVICE        │  <-- Ejecuta la lógica de negocio y transforma DTOs <-> Entidades
   └───────────┬───────────┘
               │ Opera con la Entidad (Model)
               ▼
   ┌───────────────────────┐
   │      REPOSITORY       │  <-- Consultas a la base de datos (Spring Data JPA / Query Methods)
   └───────────┬───────────┘
               │ SQL Automático / JPQL
               ▼
   ┌───────────────────────┐
   │     BASE DE DATOS     │  <-- MySQL
   └───────────────────────┘
```

---

## 🧩 Explicación Detallada de cada Capa

### 1. Capa de Modelo (`Model / Entity`)
* **Ubicación:** `ar.edu.centro8.desarrollo.proyectojpa.model.Persona`
* **Descripción:** Representa las **entidades de dominio** de la aplicación que se mapean directamente a tablas en la base de datos mediante anotaciones de JPA (`@Entity`, `@Id`, `@GeneratedValue`).
* **Responsabilidades:**
  - Definir la estructura de la tabla en la base de datos (atributos, clave primaria, estrategias de generación).
  - Mantener reglas de integridad propias del objeto (reglas de dominio intrínsecas).
* **Ejemplo en el proyecto (`Persona.java`):**
  ```java
  @Entity
  @AllArgsConstructor
  @Getter
  public class Persona {
      @Id
      @GeneratedValue(strategy = GenerationType.IDENTITY)
      private long id;

      private String nombre;
      private int edad;

      // Regla de dominio intrínseca en la entidad
      public void setEdad(int edad) {
          if (edad < 0 || edad > 120) {
              throw new IllegalArgumentException("La edad debe estar entre 0 y 120 años");
          }
          this.edad = edad;
      }
  }
  ```

---

### 2. Capa de Transferencia de Datos (`DTO` y `Mapper`)
* **Ubicación:** `ar.edu.centro8.desarrollo.proyectojpa.dto`
* **Descripción:** Los **DTOs (Data Transfer Objects)** son objetos diseñados exclusivamente para transportar datos entre la API REST (cliente) y la capa de servicio, **sin exponer la entidad `@Entity` de la base de datos**.
* **¿Por qué usar DTOs en lugar de enviar la Entidad directamente?**
  1. **Seguridad y Privacidad:** Evita exponer campos sensibles o internos de la base de datos.
  2. **Desacoplamiento:** Permite modificar la tabla o entidad sin romper los contratos de la API REST consumida por clientes externos.
  3. **Especialización (Entradas vs Salidas):** Permite diferenciar entre los datos que el cliente envía al crear/editar (`PersonaRequestDTO`, sin `id`) y los datos que la API devuelve (`PersonaResponseDTO`, con `id`).
  4. **Prevención de Ciclos de Referencia:** Evita bucles infinitos de serialización JSON al trabajar con relaciones JPA (`@OneToMany`, `@ManyToOne`).

#### Componentes DTO en el Proyecto:
* **`PersonaRequestDTO`:** Datos recibidos en solicitudes `POST` / `PUT`.
* **`PersonaResponseDTO`:** Datos devueltos en las respuestas HTTP (`GET`, `POST`, `PUT`).
* **`PersonaMapper`:** Clase encargada de la conversión bidireccional entre la entidad `Persona` y los DTOs.

---

### 3. Capa de Acceso a Datos (`Repository` y Query Methods)
* **Ubicación:** `ar.edu.centro8.desarrollo.proyectojpa.repository.IPersonaRepository`
* **Descripción:** Define la interfaz de persistencia que extiende de `JpaRepository<Persona, Long>`. Gracias a Spring Data JPA, **no es necesario escribir consultas SQL manuales ni clases DAO implementadas a mano** para operaciones CRUD comunes (`save`, `findById`, `findAll`, `deleteById`).

#### 🔍 Query Methods (Métodos de Consulta Derivados)
Spring Data JPA permite definir métodos en la interfaz repository cuyo comportamiento es **interpretado automáticamente a partir del nombre del método**, generando las sentencias SQL o JPQL correspondientes en tiempo de ejecución.

##### Estructura de un Query Method:
Un Query Method combina un **Prefijo de Acción** (`findBy`, `existsBy`, `countBy`, `deleteBy`) + **Nombre del Atributo** + **Criterios/Operadores** (`Containing`, `GreaterThan`, `Between`, `IgnoreCase`, etc.).

##### Ejemplos implementados en `IPersonaRepository`:
| Método en Java | Consulta SQL Generada (Aproximada) | Explicación / Uso |
| :--- | :--- | :--- |
| `Optional<Persona> findByNombre(String nombre)` | `SELECT * FROM persona WHERE nombre = ?` | Busca una persona por coincidencia exacta de nombre. Usado para validar duplicados. |
| `List<Persona> findByEdad(int edad)` | `SELECT * FROM persona WHERE edad = ?` | Recupera todas las personas que coinciden con una edad determinada. |
| `List<Persona> findByEdadGreaterThan(int edad)` | `SELECT * FROM persona WHERE edad > ?` | Retorna las personas con una edad mayor al parámetro especificado. |
| `List<Persona> findByNombreContaining(String texto)` | `SELECT * FROM persona WHERE nombre LIKE '%texto%'` | Realiza una búsqueda parcial en el nombre (operador `LIKE`). |
| `Optional<Persona> findByNombreIgnoreCase(String nombre)` | `SELECT * FROM persona WHERE LOWER(nombre) = LOWER(?)` | Busca por nombre ignorando diferencias entre mayúsculas y minúsculas. |
| `List<Persona> findByEdadBetween(int min, int max)` | `SELECT * FROM persona WHERE edad BETWEEN ? AND ?` | Filtra registros dentro de un rango de edades inclusivo. |
| `boolean existsByNombre(String nombre)` | `SELECT COUNT(*) > 0 FROM persona WHERE nombre = ?` | Retorna `true` o `false` indicando si existe algún registro con dicho nombre. |
| `long countByEdad(int edad)` | `SELECT COUNT(*) FROM persona WHERE edad = ?` | Cuenta el total de personas que tienen la edad consultada. |
| `void deleteByNombre(String nombre)` | `DELETE FROM persona WHERE nombre = ?` | Elimina directamente los registros que coincidan con el nombre. |

##### 💡 Manejo de Resultados con `Optional`

El método `findByNombre` devuelve un `Optional.empty()` si no encuentra ningún registro con ese nombre en la base de datos.
En Spring Data JPA, cuando usas `Optional` como tipo de retorno, el framework maneja la búsqueda de la siguiente manera:

* **Si encuentra la persona:** Devuelve un `Optional` que contiene el objeto dentro (`Optional.of(persona)`).
* **Si NO encuentra la persona:** Devuelve un `Optional` vacío (`Optional.empty()`), nunca devuelve `null`.

###### ¿Cómo se suele manejar este resultado?
Al recibir un `Optional`, puedes gestionar la ausencia del elemento de forma limpia y sin riesgo de lanzar un `NullPointerException`:

1. **Lanzar una excepción si no existe (Muy común en APIs REST):**
   ```java
   Persona persona = personaRepository.findByNombre("Juan")
       .orElseThrow(() -> new EntityNotFoundException("Persona no encontrada"));
   ```

2. **Devolver un valor por defecto o un null seguro:**
   ```java
   Persona persona = personaRepository.findByNombre("Juan")
       .orElse(new Persona("Invitado")); // Crea uno por defecto
   ```

3. **Verificar si existe antes de actuar:**
   ```java
   Optional<Persona> optionalPersona = personaRepository.findByNombre("Juan");
   if (optionalPersona.isPresent()) {
       Persona persona = optionalPersona.get();
       // Hacer algo con la persona
   } else {
       // Manejar el caso de que no exista
   }
   ```

---

### 4. Capa de Lógica de Negocio (`Service`)
* **Ubicación:** `ar.edu.centro8.desarrollo.proyectojpa.service` (`IPersonaService` / `PersonaService`)
* **Descripción:** Es el núcleo donde reside la **lógica de negocio**, validaciones avanzadas, orquestación de operaciones de datos y gestión de transacciones.
* **Responsabilidades:**
  - Validar reglas de negocio antes de persistir (ejemplo: verificar que no existan personas con nombres duplicados utilizando el Query Method `findByNombre`).
  - Mapear de DTO de petición a Entidad antes de guardar en el Repository.
  - Transformar Entidades obtenidas del Repository a DTOs de respuesta antes de entregarlas al Controller.
  - Manejar excepciones de negocio y lanzar errores descriptivos (`IllegalArgumentException`).

---

### 5. Capa de Presentación / API REST (`Controller`)
* **Ubicación:** `ar.edu.centro8.desarrollo.proyectojpa.controller.PersonaController`
* **Descripción:** Expone los endpoints de la API REST mediante `@RestController`. Atiende las solicitudes de clientes HTTP (`GET`, `POST`, `PUT`, `DELETE`), recibe parámetros (`@PathVariable`, `@RequestBody`) y delega la ejecución a la capa de Servicio.
* **Responsabilidades:**
  - Mapear las rutas URL y métodos HTTP (`@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`).
  - Configurar políticas CORS mediante `@CrossOrigin`.
  - Construir respuestas HTTP estandarizadas (`ResponseEntity`) incluyendo códigos de estado adecuados (`200 OK`, `201 Created`, `400 Bad Request`, `404 Not Found`, `500 Internal Server Error`).

#### Endpoints Disponibles:
- `GET /personas/traer`: Lista todas las personas registradas (`List<PersonaResponseDTO>`).
- `GET /personas/{id}`: Obtiene el detalle de una persona según su ID.
- `POST /personas/crear`: Registra una nueva persona pasando un `PersonaRequestDTO`.
- `PUT /personas/editar/{id}`: Modifica los datos de una persona existente.
- `DELETE /personas/borrar/{id}`: Elimina una persona por su ID.

---

## ⚙️ Configuración del Entorno (`application.properties`)

```properties
spring.application.name=proyectojpa

# Hibernate DDL Auto: Actualiza las tablas en la base de datos automáticamente
spring.jpa.hibernate.ddl-auto=update

# URL de conexión con creación automática de la base de datos si no existe
spring.datasource.url=jdbc:mysql://localhost:3306/proyecto_jpa?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1234
```

---

## 🚀 Cómo Ejecutar la Aplicación

1. **Requisitos:**
   - Java 21 SDK
   - Maven 3.x
   - MySQL Server corriendo en `localhost:3306`

2. **Ejecución:**
   ```bash
   mvn spring-boot:run
   ```

3. **Prueba de Endpoints con Bruno:**
   Se ha agregado la carpeta [`bruno`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/daw/Clase%208/proyectojpa/bruno) con la colección completa de peticiones.
   - Abre la aplicación **Bruno**.
   - Haz clic en **Open Collection**.
   - Selecciona la carpeta `bruno` del proyecto.
   - Selecciona el entorno **Local** (`http://localhost:8080`).

#### Colección Bruno disponible:
| Nombre en Bruno | Método HTTP | URL | Descripción |
| :--- | :--- | :--- | :--- |
| **Obtener Personas** | `GET` | `{{baseUrl}}/personas/traer` | Trae la lista de todas las personas |
| **Crear Persona** | `POST` | `{{baseUrl}}/personas/crear` | Crea una nueva persona enviando JSON |
| **Obtener Persona por ID** | `GET` | `{{baseUrl}}/personas/{id}` | Busca una persona específica por ID |
| **Editar Persona** | `PUT` | `{{baseUrl}}/personas/editar/{id}` | Actualiza datos de una persona por ID |
| **Eliminar Persona** | `DELETE` | `{{baseUrl}}/personas/borrar/{id}` | Elimina una persona por ID |

