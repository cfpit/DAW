package objetos;

public class Auto {
    // atributos
    public String marca;
    private int velocidad;

    // constructor vacio
    public Auto() {
    }

    // sobrecargo el constructor
    public Auto(String marca, int velocidad) {
        this.marca = marca;
        this.setVelocidad(velocidad);
    }

    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        //regla de negocio
        if(velocidad >= 0 && velocidad <= 130){
            this.velocidad = velocidad;
        }else{
            System.out.println("Velocidad fuera de rango");
        }
    }

    // metodos
    public void acelerar() {
        this.setVelocidad(this.velocidad + 10);
    }

    // sobrecarga del metodo acelerar
    public void acelerar(int km) {
        this.setVelocidad(this.velocidad + km);
    }

    @Override
    public String toString() {
        return "marca=" + marca + ", velocidad=" + velocidad;
    }

}
