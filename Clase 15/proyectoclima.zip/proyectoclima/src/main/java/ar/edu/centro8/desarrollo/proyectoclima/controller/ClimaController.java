package ar.edu.centro8.desarrollo.proyectoclima.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import ar.edu.centro8.desarrollo.proyectoclima.model.Clima;
import ar.edu.centro8.desarrollo.proyectoclima.service.ClimaService;

@Controller
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE })
public class ClimaController {

    @Autowired
    private ClimaService climaService;

    // Endpoint REST que retorna el clima actual en formato JSON
    @GetMapping("/api/clima")
    @ResponseBody
    public Clima obtenerClimaAPI() {
        return climaService.obtenerClimaCaba();
    }

    // Endpoint que retorna la vista HTML con Thymeleaf y estilos Bootstrap
    @GetMapping({"/", "/clima"})
    public String obtenerClimaVista(Model model) {
        try {
            Clima clima = climaService.obtenerClimaCaba();
            model.addAttribute("clima", clima);
        } catch (Exception e) {
            model.addAttribute("error", "Error al obtener la información del clima: " + e.getMessage());
            model.addAttribute("clima", new Clima());
        }
        return "clima";
    }

}

