package ar.edu.centro8.desarrollo.proyectoclima;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import ar.edu.centro8.desarrollo.proyectoclima.model.Clima;
import ar.edu.centro8.desarrollo.proyectoclima.service.ClimaService;

@SpringBootTest
class ClimaServiceTest {

    @Autowired
    private ClimaService climaService;

    @Test
    void testObtenerClimaCaba() {
        Clima clima = climaService.obtenerClimaCaba();
        assertNotNull(clima, "El objeto Clima no debe ser nulo");
        assertNotNull(clima.getTemperatura(), "La temperatura no debe ser nula");
        assertNotNull(clima.getCiudad(), "La ciudad no debe ser nula");
        assertTrue(clima.getCiudad().contains("CABA"), "Debe ser CABA");
        System.out.println(">>> Clima actual CABA obtenido con éxito: " + clima.getTemperatura() + "°C, " + clima.getDescripcion());
    }

}

